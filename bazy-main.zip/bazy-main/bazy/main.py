import tkinter as tk
import oracledb
import xml.etree.ElementTree as ET
from tkinter import ttk

dsn = oracledb.makedsn(host='217.173.198.135', port=1521, service_name='tpdb')
conn = oracledb.connect(user='s100911', password='s100911', dsn=dsn)
cursor = conn.cursor()

def import_data():
    table_name = select_box.get()  # Pobierz wybraną wartość z Combobox
    
    file_name = f"{table_name}.xml"
    cursor.execute(f"SELECT * FROM {table_name}")
    
    results = cursor.fetchall()
    
    root = ET.Element(table_name)
    
    for row in results:
        wiersz = ET.SubElement(root, "Wiersz")
        
        for i, column_name in enumerate(cursor.description):
            column_value = row[i]
            column = ET.SubElement(wiersz, column_name[0])
            column.text = str(column_value)
    
    tree = ET.ElementTree(root)
    tree.write(file_name, encoding="utf-8", xml_declaration=True)
    
    print(f"Dane z tabeli {table_name} zostały zapisane do pliku {file_name}")


def export_data():
    file_name = select_box.get()  # Assuming the file name is selected from the combobox

    dsn = oracledb.makedsn(host='217.173.198.135', port=1521, service_name='tpdb')
    conn = oracledb.connect(user='s100911', password='s100911', dsn=dsn)
    cursor = conn.cursor()

    # Parse the XML file
    tree = ET.parse(file_name)
    root = tree.getroot()

    # Iterate over the XML elements and retrieve the data
    for element in root:
        value1 = element.find('value1').text
        value2 = element.find('value2').text

        # Construct the INSERT statement
        insert_statement = f"INSERT INTO your_table_name (column1, column2) VALUES ('{value1}', '{value2}')"

        # Execute the INSERT statement
        cursor.execute(insert_statement)

    conn.commit()

    cursor.close()
    conn.close()

def fetch_data():
    table_name = select_box.get()

    dsn = oracledb.makedsn(host='217.173.198.135', port=1521, service_name='tpdb')
    conn = oracledb.connect(user='s100911', password='s100911', dsn=dsn)
    cursor = conn.cursor()

    # Retrieve column names
    cursor.execute(f"SELECT * FROM {table_name} WHERE ROWNUM = 1")
    column_names = [desc[0] for desc in cursor.description]

    # Fetch all rows from the table
    cursor.execute(f"SELECT * FROM {table_name}")
    results = cursor.fetchall()

    result_text.delete("1.0", tk.END)

    # Insert column names into the result_text
    result_text.insert(tk.END, " | ".join(column_names) + "\n")

    for row in results:
        result_text.insert(tk.END, " | ".join(str(cell) for cell in row) + "\n")

    cursor.close()
    conn.close()

def add_data():
    value1 = input_field1.get()
    table_name = select_box.get()
    dsn = oracledb.makedsn(host='217.173.198.135', port=1521, service_name='tpdb')
    conn = oracledb.connect(user='s100911', password='s100911', dsn=dsn)
    cursor = conn.cursor()

    cursor.execute(f"SELECT * FROM {table_name} WHERE ROWNUM = 1")
    column_names = [desc[0] for desc in cursor.description]

    # Skip the first column name
    column_names = column_names[1:]

    print(f"Value 1: {value1}")
    print("Column names:", column_names)

    # Construct the INSERT statement
    insert_statement = f"INSERT INTO {table_name} ({', '.join(column_names)}) VALUES ({value1})"

    cursor.execute(insert_statement)
    conn.commit()

    input_field1.delete(0, tk.END)

    cursor.close()
    conn.close()

def delete_data():
    dsn = oracledb.makedsn(host='217.173.198.135', port=1521, service_name='tpdb')
    conn = oracledb.connect(user='s100911', password='s100911', dsn=dsn)
    cursor = conn.cursor()

    value2 = input_field2.get()
    table_name = select_box.get()

    cursor.execute(f"SELECT * FROM {table_name} WHERE ROWNUM = 1")
    column_names = [desc[0] for desc in cursor.description]
    print(column_names)
    # Retrieve the first column name
    column_name = column_names[0]

    delete_statement = f"DELETE FROM {table_name} WHERE {column_name} = '{value2}'"

    cursor.execute(delete_statement)
    conn.commit()

    cursor.close()
    conn.close()

    print(f"Value 2: {value2}")
    input_field2.delete(0, tk.END)

window = tk.Tk()
window.geometry("600x600")

blank_space = tk.Label(window, text=" ")
blank_space.pack()

button_frame = tk.Frame(window)
button_frame.pack(side=tk.BOTTOM)

imp = tk.Button(button_frame, text="Import", command=import_data)
fetch_button = tk.Button(button_frame, text="Pobierz dane", command=fetch_data)
add_button = tk.Button(button_frame, text="Dodaj", command=add_data)
delete_button = tk.Button(button_frame, text="Usuń", command=delete_data)
export_button = tk.Button(button_frame, text="Eksport", command=export_data)

imp.pack(side=tk.LEFT)
fetch_button.pack(side=tk.LEFT)
add_button.pack(side=tk.LEFT)
delete_button.pack(side=tk.LEFT)
export_button.pack(side=tk.LEFT)

select_box = ttk.Combobox(button_frame, values=["archival_cars", "car_info","cars","client","client_info","mechanic","order_car","order_one","payments","reserved","umowy"])
select_box.pack(side=tk.LEFT)

input_frame = tk.Frame(window)
input_frame.pack()

label1 = tk.Label(input_frame, text="dodawanie:")
label1.pack(side=tk.LEFT)
input_field1 = tk.Entry(input_frame)
input_field1.pack(side=tk.LEFT)

label2 = tk.Label(input_frame, text="usuwanie:")
label2.pack(side=tk.LEFT)
input_field2 = tk.Entry(input_frame)
input_field2.pack(side=tk.LEFT)

result_text = tk.Text(window)
result_text.pack()

window.mainloop()

